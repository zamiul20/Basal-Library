# Pyarmor 9.2.5 (trial), 000000, 2026-06-28T22:33:35.535600
from .pyarmor_runtime import __pyarmor__
